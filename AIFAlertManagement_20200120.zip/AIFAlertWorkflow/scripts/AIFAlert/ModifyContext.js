/*
// read from existing workflow context 
var productInfo = $.context.productInfo; 
var productName = productInfo.productName; 
var productDescription = productInfo.productDescription;

// read contextual information
var taskDefinitionId = $.info.taskDefinitionId;

// read user task information
var lastUserTask1 = $.usertasks.usertask1.last;
var userTaskSubject = lastUserTask1.subject;
var userTaskProcessor = lastUserTask1.processor;
var userTaskCompletedAt = lastUserTask1.completedAt;

var userTaskStatusMessage = " User task '" + userTaskSubject + "' has been completed by " + userTaskProcessor + " at " + userTaskCompletedAt;

// create new node 'product'
var product = {
		productDetails: productName  + " " + productDescription,
		workflowStep: taskDefinitionId
};

// write 'product' node to workflow context
$.context.product = product;
*/

//$.context.taskProcessor = $.context.initiator;
var systemInfo = $.context.alertData.system;
var ibn = $.context.alertData.ibn;
ibn = ibn.replace("%252f", "%2f"); // Fix the encode error 
if(systemInfo === "SAL")
{
	ibn = ibn.replace("ui2/flp?sap-client=000&sap-language=EN#AIFMessage-manage?", "webdynpro/aifx/wda_msg_monitor?WDCONFIGURATIONID=%2fAIFX%2fWDAC_MSG_MONITOR&");
	$.context.alertData.ibn = ibn;
}

